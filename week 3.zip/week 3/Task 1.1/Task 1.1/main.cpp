#include<iostream>
using namespace std;

class Time
{
    int h;
    int m;
    int s;
    public:
    Time(){
        h = 0;
        m = 0;
        s = 0;
    }
    
    void getData()
    {
        cout<<"Input Hour = "<<endl;
        cin>>h;
        while(h>24){
            cout<<"Input valid Hour = "<<endl;
            cin>>h;
        }
        
        cout<<"Input Minute = "<<endl;
        cin>>m;
        while(m>60){
            cout<<"Input valid Minute = "<<endl;
            cin>>m;
        }
        
        cout<<"Input Second "<<endl;
        cin>>s;
        while(s>60){
            cout<<"Input valid Second "<<endl;
            cin>>s;
        }
    }
    
    Time operator+(Time T){
        Time temp;
        temp.s = T.s + s;
        int ss = temp.s / 60;
        temp.s = temp.s % 60;
        temp.m = ss + T.m + m;
        int mm = temp.m / 60;
        temp.m = temp.m % 60;
        temp.h = mm + T.h + h;
        return (temp);
    }
    
    bool operator>(Time T) {
        if (h > T.h)
            return true;
        else if (h == T.h && m > T.m)
            return true;
        else if (h == T.h && m == T.m && s > T.s)
            return true;
        else
            return false;
    }
    
    void display(){
        cout<<"Addition of two times = "<<h<<" h "<<m<<" min "<<s<<" sec"<<endl;
    }
    
    void comparisonDisplay(){
        cout<<h<<" hour "<<m<<" minute "<<s<<" secound";
    }
};

int main()

{
    Time T1;
    T1.getData();
    Time T2;
    T2.getData();
    Time T3 = T1 + T2;
    T3.display();
    
    if(T1 > T2){
        cout<<"Time 1(";
        T1.comparisonDisplay();
        cout<<") is greater than T2(";
        T2.comparisonDisplay();
        cout<<").";
    }
    
    else if(T2 > T1){
        cout<<"Time 2(";
        T2.comparisonDisplay();
        cout<<") is greater than T1(";
        T1.comparisonDisplay();
        cout<<").";
    }
    
    else{
        cout<<"Time 1(";
        T1.comparisonDisplay();
        cout<<") and T2";
        T2.comparisonDisplay();
        cout<<") are equal.";
    }
    
return 0;
    
}

