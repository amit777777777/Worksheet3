#include<iostream>
#include<string>
#include<fstream>
using namespace std;

class Vehicle
{
    protected:
    int reg;
    string col;
    public:
    Vehicle(int RN, string Cl){
        reg = RN;
        col = Cl;
    }
    virtual void V_Information(){
        ofstream file("vehicle.txt", ios::app);
        if(file.is_open()){
            file<<"Vehicle Details: "<<endl;
            file<<"Registration Number: "<<reg<<endl;
            file<<"Color: "<<col<<endl;
            file.close();
        }
    }
};

class Car : public Vehicle{
    protected:
    int numOfSeats;
    public:
    Car(int RN, string Cl, int NS) : Vehicle(RN, Cl){
        numOfSeats = NS;
    }
    void V_Information() override{
        ofstream file("vehicle.txt", ios::app);
        if(file.is_open()){
            file<<"Car Details: "<<endl;
            file<<"Registration Number: "<<reg<<endl;
            file<<"Color: "<<col<<endl;
            file<<"Number of Seats: "<<numOfSeats<<endl;
            file.close();
        }
    }
};

class Bike : public Vehicle{
    protected:
    int engineCap;
    public:
    Bike(int RN, string Cl, int EC) : Vehicle(RN, Cl){
        engineCap = EC;
    }
    void V_Information() override{
        ofstream file("vehicle.txt", ios::app);
        if(file.is_open()){
            file<<"Bike Details: "<<endl;
            file<<"Registration Number: "<<reg<<endl;
            file<<"Color: "<<col<<endl;
            file<<"Engine Capacity: "<<engineCap<<endl;
            file.close();
        }
    }
};

int main()
{
    Car c1(6343735,"Dark_blue",2);
    Bike b1(434332,"Black",800);
    c1.V_Information();
    b1.V_Information();
    
return 0;
}
