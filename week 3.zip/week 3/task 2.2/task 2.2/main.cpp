#include <iostream>
#include <fstream>
using namespace std;

class Student {
public:
    int roll, marks;
    string name;

    void input() {
        cout << "Roll: "; cin >> roll;
        cout << "Name: "; cin >> name;
        cout << "Marks (0-100): "; cin >> marks;
    }

    bool isValid() const {
        return marks >= 0 && marks <= 100;
    }

    void read(ifstream& f) { f >> roll >> name >> marks; }
    void write(ofstream& f) const { f << roll << " " << name << " " << marks << endl; }
};

int main() {
    Student list[100], newStu;
    int count = 0;

    ifstream in("students.txt");
    while (in && count < 100) {
        list[count].read(in);
        if (in) count++;
    }
    in.close();

    newStu.input();

    if (!newStu.isValid()) {
        cout << "Invalid marks!\n"; return 1;
    }

    for (int i = 0; i < count; i++) {
        if (list[i].roll == newStu.roll) {
            cout << "Duplicate roll!\n"; return 1;
        }
    }

    if (count < 100) list[count++] = newStu;
    else { cout << "Limit reached!\n"; return 1; }

    ofstream out("students.txt");
    for (int i = 0; i < count; i++) list[i].write(out);
    out.close();

    cout << "Student saved.\n";
    return 0;
}


